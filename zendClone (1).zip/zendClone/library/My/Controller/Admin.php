<?php
class My_Controller_Admin extends My_Controller_Abstract{
    
    public function preDispatch() {
        parent::preDispatch();
        
        $auth = Zend_Auth::getInstance();
        $auth->setStorage(new Zend_Auth_Storage_Session('login'));
        
        if ($auth->hasIdentity()) {
            $isAdult = $_COOKIE['adult'];
            if ($isAdult) {
               // return $this->_redirect("/chat/chat");
            }else {
                return $this->_redirect("/index/confirm");
            }
        } else {
            $this->_redirect($this->baseUrl());
        }
    }
}
?>
