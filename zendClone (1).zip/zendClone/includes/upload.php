<?php

include_once(APPLICATION_PATH.'/../includes/config.php');
include_once(APPLICATION_PATH.'/../includes/functions.php');

if ($_REQUEST['act'] == 'thumb') {
	$arr = array(
		'uploaddir' => $imgthumb,
		'tempdir' => $imgtemp,
		'height' => $_REQUEST['height'],
		'width' => $_REQUEST['width'],
		'x' => $_REQUEST['x'],
		'y' => $_REQUEST['y'],
		'img_src' => APPLICATION_PATH.'/../public/uploads/big/' .end(explode('/',$_REQUEST['img_src'])),
		'already_profile_img' => $_REQUEST['already_profile_img'],
		'coverimage' => $_REQUEST['coverimage'],
		'filename' => $_REQUEST['filename'],
		'thumb' => true,
		'fileError' => $fileError,
		'sizeError' => $sizeError,
		'maxfilesize' => $maxuploadfilesize,
		'canvasbg' => $canvasbg,
		'bigWidthPrev' => $bigHeightPrev,
		'bigHeightPrev' => $bigHeightPrev,
	);
	resizeThumb($arr);
	exit;
} elseif ($_REQUEST['act'] == 'upload') {

	$big_arr = array(
		'uploaddir' => $imgbig,
		'tempdir' => $imgtemp,
		'height' => $_REQUEST['height'],
		'width' => $_REQUEST['width'],
		'x' => 0,
		'y' => 0,
		'thumb' => false,
		'fileError' => $fileError,
		'sizeError' => $sizeError,
		'maxfilesize' => $maxuploadfilesize,
		'canvasbg' => $canvasbg,
		'bigWidthPrev' => $bigHeightPrev,
		'bigHeightPrev' => $bigHeightPrev,
	);

	resizeImg($big_arr);
	
} else {
	//nothing to do here
}
